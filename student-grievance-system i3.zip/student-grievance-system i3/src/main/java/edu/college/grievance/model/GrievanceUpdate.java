package edu.college.grievance.model;

import java.sql.Timestamp;

public class GrievanceUpdate {
    private String authorName, authorRole, updateType, message;
    private Timestamp createdAt;
    public String getAuthorName() { return authorName; } public void setAuthorName(String v) { authorName = v; }
    public String getAuthorRole() { return authorRole; } public void setAuthorRole(String v) { authorRole = v; }
    public String getUpdateType() { return updateType; } public void setUpdateType(String v) { updateType = v; }
    public String getMessage() { return message; } public void setMessage(String v) { message = v; }
    public Timestamp getCreatedAt() { return createdAt; } public void setCreatedAt(Timestamp v) { createdAt = v; }
}
