package edu.college.grievance.util;

import jakarta.servlet.http.HttpServletRequest;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public final class Csrf {
    private static final SecureRandom RANDOM = new SecureRandom();
    private Csrf() {}
    public static String token(HttpServletRequest req) {
        String token = (String) req.getSession().getAttribute("csrfToken");
        if (token == null) {
            byte[] bytes = new byte[32]; RANDOM.nextBytes(bytes);
            token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            req.getSession().setAttribute("csrfToken", token);
        }
        return token;
    }
    public static boolean valid(HttpServletRequest req) {
        String expected = (String) req.getSession().getAttribute("csrfToken");
        String supplied = req.getParameter("csrfToken");
        if (expected == null || supplied == null) return false;
        return MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8), supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
