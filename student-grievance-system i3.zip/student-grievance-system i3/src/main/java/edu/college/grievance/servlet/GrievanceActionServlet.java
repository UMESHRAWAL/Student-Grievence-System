package edu.college.grievance.servlet;

import edu.college.grievance.dao.GrievanceDao;
import edu.college.grievance.model.Grievance;
import edu.college.grievance.model.User;
import edu.college.grievance.util.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Set;

@WebServlet(urlPatterns={"/grievances/message","/grievances/escalate","/grievances/status","/grievances/assign"})
public class GrievanceActionServlet extends HttpServlet {
    private final GrievanceDao dao=new GrievanceDao();
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException {
        User user=Web.user(req);String path=req.getServletPath();long id;
        try{id=Validation.positiveId(req.getParameter("id"));}catch(IllegalArgumentException ex){resp.sendError(400);return;}
        try {
            Grievance g=dao.findVisible(id,user);if(g==null){resp.sendError(404);return;}
            if(user.isOfficer()&&g.getOfficerName()==null){resp.sendError(403);return;}
            boolean ok;
            switch(path) {
                case "/grievances/message" -> {String msg=Validation.bounded(req.getParameter("message"),"Message",2,2000);if("CLOSED".equals(g.getStatus())){resp.sendError(409,"This case is closed.");return;}ok=dao.addMessage(id,user.getId(),msg);}
                case "/grievances/escalate" -> {if("RESOLVED".equals(g.getStatus())||"CLOSED".equals(g.getStatus())){resp.sendError(409,"Resolved or closed grievances cannot be escalated.");return;}if(g.getEscalationLevel()>=3){resp.sendError(409,"Maximum escalation level reached.");return;}String msg=Validation.bounded(req.getParameter("reason"),"Escalation reason",5,1000);ok=dao.escalate(id,user.getId(),"Escalated by "+user.getRole().toLowerCase()+": "+msg);}
                case "/grievances/status" -> {String status=Validation.oneOf(req.getParameter("status"),"status","IN_PROGRESS","WAITING_ON_STUDENT","RESOLVED","CLOSED");if(!allowedStatus(user,g,status)){resp.sendError(403,"That status change is not allowed.");return;}String msg=Validation.bounded(req.getParameter("message"),"Update note",3,1000);ok=dao.status(id,status,user.getId(),"Status changed to "+status.replace('_',' ')+". "+msg);}
                case "/grievances/assign" -> {if(!user.isAdmin()){resp.sendError(403);return;}long officerId=Validation.positiveId(req.getParameter("officerId"));edu.college.grievance.model.User officer=new edu.college.grievance.dao.UserDao().findById(officerId);if(officer==null||!officer.isOfficer()){resp.sendError(400,"Choose an active officer.");return;}String note="Assigned to officer. "+(req.getParameter("note")==null?"":Validation.bounded(req.getParameter("note"),"Assignment note",0,500));ok=dao.assign(id,officerId,user.getId(),note);}
                default -> {resp.sendError(404);return;}
            }
            if(!ok){resp.sendError(409,"The grievance has changed. Refresh and try again.");return;}Web.message(req,"success","Update saved.");resp.sendRedirect(req.getContextPath()+"/grievances/view?id="+id);
        }catch(IllegalArgumentException ex){Web.message(req,"error",ex.getMessage());resp.sendRedirect(req.getContextPath()+"/grievances/view?id="+id);}
        catch(Exception ex){getServletContext().log("Grievance action failed",ex);Web.message(req,"error","That action could not be completed. Please refresh and try again.");resp.sendRedirect(req.getContextPath()+"/grievances/view?id="+id);}
    }
    private boolean allowedStatus(User u,Grievance g,String next) {
        if(u.isAdmin())return true;
        if(u.isStudent())return "RESOLVED".equals(g.getStatus())&&"CLOSED".equals(next)||"RESOLVED".equals(g.getStatus())&&"IN_PROGRESS".equals(next);
        if(!u.isOfficer()||"CLOSED".equals(g.getStatus())||"RESOLVED".equals(g.getStatus()))return false;
        return Set.of("IN_PROGRESS","WAITING_ON_STUDENT","RESOLVED").contains(next);
    }
}
