package edu.college.grievance.dao;

import edu.college.grievance.model.User;
import edu.college.grievance.util.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    public record LoginRecord(User user, String passwordHash) {}
    public LoginRecord findLogin(String email) throws SQLException {
        String sql = "SELECT id,full_name,email,role,password_hash FROM users WHERE email=? AND active=TRUE";
        try (Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,email); try(ResultSet r=p.executeQuery()) {
                return r.next() ? new LoginRecord(new User(r.getLong("id"),r.getString("full_name"),r.getString("email"),r.getString("role")),r.getString("password_hash")) : null;
            }
        }
    }
    public User findById(long id) throws SQLException {
        try(Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement("SELECT id,full_name,email,role FROM users WHERE id=? AND active=TRUE")) {
            p.setLong(1,id); try(ResultSet r=p.executeQuery()) { return r.next()?new User(r.getLong(1),r.getString(2),r.getString(3),r.getString(4)):null; }
        }
    }
    public void create(String name,String email,String hash,String role) throws SQLException {
        try(Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement("INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,?)")) {
            p.setString(1,name);p.setString(2,email);p.setString(3,hash);p.setString(4,role);p.executeUpdate();
        }
    }
    public List<User> officers() throws SQLException {
        List<User> out=new ArrayList<>();
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT id,full_name,email,role FROM users WHERE role='OFFICER' AND active=TRUE ORDER BY full_name");ResultSet r=p.executeQuery()) {
            while(r.next())out.add(new User(r.getLong(1),r.getString(2),r.getString(3),r.getString(4)));
        }
        return out;
    }
    public long adminCount() throws SQLException {
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM users WHERE role='ADMIN' AND active=TRUE");ResultSet r=p.executeQuery()) {
            r.next();return r.getLong(1);
        }
    }
}
