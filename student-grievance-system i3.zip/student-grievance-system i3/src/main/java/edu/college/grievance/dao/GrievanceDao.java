package edu.college.grievance.dao;

import edu.college.grievance.model.Grievance;
import edu.college.grievance.model.User;
import edu.college.grievance.util.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GrievanceDao {
    private static final String SELECT = "SELECT g.*,s.full_name student_name,o.full_name officer_name FROM grievances g JOIN users s ON s.id=g.student_id LEFT JOIN users o ON o.id=g.assigned_officer_id ";
    private Grievance map(ResultSet r)throws SQLException {
        Grievance g=new Grievance();g.setId(r.getLong("id"));g.setTrackingCode(r.getString("tracking_code"));g.setTitle(r.getString("title"));
        g.setCategory(r.getString("category"));g.setPriority(r.getString("priority"));g.setDescription(r.getString("description"));g.setStatus(r.getString("status"));
        g.setEscalationLevel(r.getInt("escalation_level"));g.setCreatedAt(r.getTimestamp("created_at"));g.setUpdatedAt(r.getTimestamp("updated_at"));
        g.setStudentName(r.getString("student_name"));g.setOfficerName(r.getString("officer_name"));return g;
    }
    public String create(long studentId,String title,String category,String priority,String description)throws SQLException {
        String code=UUID.randomUUID().toString().replace("-","").substring(0,12).toUpperCase();
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO grievances(tracking_code,student_id,title,category,priority,description) VALUES(?,?,?,?,?,?)")) {
            p.setString(1,code);p.setLong(2,studentId);p.setString(3,title);p.setString(4,category);p.setString(5,priority);p.setString(6,description);p.executeUpdate();
        }
        return code;
    }
    public List<Grievance> listFor(User user)throws SQLException {
        String query=user.isStudent()?SELECT+"WHERE g.student_id=? ORDER BY g.updated_at DESC LIMIT 250":user.isOfficer()?SELECT+"WHERE g.assigned_officer_id=? ORDER BY g.updated_at DESC LIMIT 250":SELECT+"ORDER BY CASE WHEN g.priority='URGENT' THEN 0 ELSE 1 END,g.updated_at DESC LIMIT 250";
        List<Grievance> out=new ArrayList<>();try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(query)) {
            if(!user.isAdmin())p.setLong(1,user.getId());try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r));}
        }return out;
    }
    public Grievance findVisible(long id,User user)throws SQLException {
        String sql=SELECT+"WHERE g.id=? AND (g.student_id=? OR g.assigned_officer_id=? OR ?=TRUE)";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(sql)) {
            p.setLong(1,id);p.setLong(2,user.getId());p.setLong(3,user.getId());p.setBoolean(4,user.isAdmin());
            try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}
        }
    }
    public boolean assign(long id,long officerId,long adminId,String note)throws SQLException {
        try(Connection c=Database.getConnection()) {
            c.setAutoCommit(false);
            try(PreparedStatement p=c.prepareStatement("UPDATE grievances SET assigned_officer_id=?,status=IF(status='NEW','ASSIGNED',status) WHERE id=?")) {
                p.setLong(1,officerId);p.setLong(2,id);if(p.executeUpdate()!=1){c.rollback();return false;}
            }
            try(PreparedStatement p=c.prepareStatement("INSERT INTO grievance_updates(grievance_id,author_id,update_type,message) VALUES(?,?, 'ASSIGNMENT',?)")) {
                p.setLong(1,id);p.setLong(2,adminId);p.setString(3,note);p.executeUpdate();
            }c.commit();return true;
        }
    }
    public boolean status(long id,String status,long actorId,String message)throws SQLException {
        try(Connection c=Database.getConnection()) {
            c.setAutoCommit(false);
            String previous;
            try(PreparedStatement p=c.prepareStatement("SELECT status FROM grievances WHERE id=? FOR UPDATE")) {
                p.setLong(1,id);try(ResultSet r=p.executeQuery()){if(!r.next()){c.rollback();return false;}previous=r.getString(1);}
            }
            try(PreparedStatement p=c.prepareStatement("UPDATE grievances SET status=? WHERE id=?")) {
                p.setString(1,status);p.setLong(2,id);if(p.executeUpdate()!=1){c.rollback();return false;}
            }
            try(PreparedStatement p=c.prepareStatement("INSERT INTO grievance_updates(grievance_id,author_id,update_type,message) VALUES(?,?,?,?)")) {
                p.setLong(1,id);p.setLong(2,actorId);p.setString(3,"RESOLVED".equals(previous)&&"IN_PROGRESS".equals(status)?"REOPENED":"STATUS");p.setString(4,message);p.executeUpdate();
            }c.commit();return true;
        }
    }
    public boolean escalate(long id,long actorId,String message)throws SQLException {
        try(Connection c=Database.getConnection()) {
            c.setAutoCommit(false);
            try(PreparedStatement p=c.prepareStatement("UPDATE grievances SET escalation_level=LEAST(escalation_level+1,3) WHERE id=? AND status NOT IN ('RESOLVED','CLOSED') AND escalation_level<3")) {
                p.setLong(1,id);if(p.executeUpdate()!=1){c.rollback();return false;}
            }
            try(PreparedStatement p=c.prepareStatement("INSERT INTO grievance_updates(grievance_id,author_id,update_type,message) VALUES(?,?,'ESCALATION',?)")) {
                p.setLong(1,id);p.setLong(2,actorId);p.setString(3,message);p.executeUpdate();
            }c.commit();return true;
        }
    }
    public boolean addMessage(long id,long actorId,String message)throws SQLException {
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO grievance_updates(grievance_id,author_id,update_type,message) VALUES(?,?,'MESSAGE',?)")) {
            p.setLong(1,id);p.setLong(2,actorId);p.setString(3,message);return p.executeUpdate()==1;
        }
    }
    public List<Grievance> findByTracking(String code,long studentId)throws SQLException {
        List<Grievance> out=new ArrayList<>();try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(SELECT+"WHERE g.student_id=? AND g.tracking_code=?")) {
            p.setLong(1,studentId);p.setString(2,code);try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r));}
        }return out;
    }
}
