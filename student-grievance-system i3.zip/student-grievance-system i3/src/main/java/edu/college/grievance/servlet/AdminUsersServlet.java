package edu.college.grievance.servlet;

import edu.college.grievance.dao.UserDao;
import edu.college.grievance.model.User;
import edu.college.grievance.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;

@WebServlet("/admin/officers")
public class AdminUsersServlet extends HttpServlet {
    private final UserDao users=new UserDao();
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        if(!Web.user(req).isAdmin()){resp.sendError(403);return;}
        try{req.setAttribute("officers",users.officers());req.getRequestDispatcher("/WEB-INF/views/admin-officers.jsp").forward(req,resp);}
        catch(Exception ex){getServletContext().log("Officer list failed",ex);resp.sendError(500);}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        if(!Web.user(req).isAdmin()){resp.sendError(403);return;}
        try {
            String name=Validation.bounded(req.getParameter("fullName"),"Name",2,100);String email=Validation.email(req.getParameter("email"));String password=req.getParameter("password");
            Passwords.validate(password);if(!password.equals(req.getParameter("confirmPassword")))throw new IllegalArgumentException("The passwords do not match.");
            users.create(name,email,Passwords.hash(password),"OFFICER");Web.message(req,"success","Officer account created. Share the temporary password securely with the officer.");Web.redirect(req,resp,"/admin/officers");
        }catch(SQLIntegrityConstraintViolationException ex){Web.message(req,"error","An account with that email already exists.");Web.redirect(req,resp,"/admin/officers");}
        catch(IllegalArgumentException ex){Web.message(req,"error",ex.getMessage());Web.redirect(req,resp,"/admin/officers");}
        catch(Exception ex){getServletContext().log("Officer creation failed",ex);Web.message(req,"error","The officer account could not be created.");Web.redirect(req,resp,"/admin/officers");}
    }
}
