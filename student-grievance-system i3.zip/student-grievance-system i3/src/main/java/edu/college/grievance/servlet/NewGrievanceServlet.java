package edu.college.grievance.servlet;

import edu.college.grievance.dao.GrievanceDao;
import edu.college.grievance.model.User;
import edu.college.grievance.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/grievances/new")
public class NewGrievanceServlet extends HttpServlet {
    private final GrievanceDao dao=new GrievanceDao();
    private boolean student(HttpServletRequest r,HttpServletResponse s)throws IOException {if(!Web.user(r).isStudent()){s.sendError(403);return false;}return true;}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {if(!student(req,resp))return;req.getRequestDispatcher("/WEB-INF/views/new-grievance.jsp").forward(req,resp);}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        if(!student(req,resp))return;
        try {
            String title=Validation.bounded(req.getParameter("title"),"Title",5,120);String category=Validation.oneOf(req.getParameter("category"),"category","ACADEMIC","FACILITIES","HOSTEL","FINANCE","HARASSMENT","OTHER");
            String priority=Validation.oneOf(req.getParameter("priority"),"priority","NORMAL","URGENT");String description=Validation.bounded(req.getParameter("description"),"Description",20,4000);
            String code=dao.create(Web.user(req).getId(),title,category,priority,description);Web.message(req,"success","Grievance submitted. Keep this tracking code: "+code);Web.redirect(req,resp,"/dashboard");
        }catch(IllegalArgumentException ex){Web.error(req,ex.getMessage());req.getRequestDispatcher("/WEB-INF/views/new-grievance.jsp").forward(req,resp);}
        catch(Exception ex){getServletContext().log("Grievance create failed",ex);Web.error(req,"The grievance could not be submitted. Please try again.");req.getRequestDispatcher("/WEB-INF/views/new-grievance.jsp").forward(req,resp);}
    }
}
