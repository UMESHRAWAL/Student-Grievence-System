package edu.college.grievance.servlet;

import edu.college.grievance.dao.GrievanceDao;
import edu.college.grievance.dao.UserDao;
import edu.college.grievance.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private final GrievanceDao grievances=new GrievanceDao();private final UserDao users=new UserDao();
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        try {User user=(User)req.getSession().getAttribute("user");req.setAttribute("grievances",grievances.listFor(user));if(user.isAdmin())req.setAttribute("officers",users.officers());req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req,resp);}
        catch(Exception ex){getServletContext().log("Dashboard load failed",ex);resp.sendError(500,"Unable to load the dashboard.");}
    }
}
