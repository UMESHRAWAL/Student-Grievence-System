package edu.college.grievance.dao;

import edu.college.grievance.model.GrievanceUpdate;
import edu.college.grievance.util.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UpdateDao {
    public List<GrievanceUpdate> list(long grievanceId)throws SQLException {
        List<GrievanceUpdate> out=new ArrayList<>();String sql="SELECT u.update_type,u.message,u.created_at,a.full_name,a.role FROM grievance_updates u JOIN users a ON a.id=u.author_id WHERE u.grievance_id=? ORDER BY u.created_at,u.id";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(sql)) {
            p.setLong(1,grievanceId);try(ResultSet r=p.executeQuery()){while(r.next()){GrievanceUpdate u=new GrievanceUpdate();u.setUpdateType(r.getString(1));u.setMessage(r.getString(2));u.setCreatedAt(r.getTimestamp(3));u.setAuthorName(r.getString(4));u.setAuthorRole(r.getString(5));out.add(u);}}
        }return out;
    }
}
