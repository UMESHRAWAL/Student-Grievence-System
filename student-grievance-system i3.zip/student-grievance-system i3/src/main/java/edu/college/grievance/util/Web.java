package edu.college.grievance.util;

import edu.college.grievance.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public final class Web {
    private Web() {}
    public static User user(HttpServletRequest req) { return (User) req.getSession(false).getAttribute("user"); }
    public static void message(HttpServletRequest req, String kind, String text) {
        req.getSession().setAttribute("flashKind", kind);
        req.getSession().setAttribute("flashMessage", text);
    }
    public static void redirect(HttpServletRequest req, HttpServletResponse resp, String path) throws java.io.IOException {
        resp.sendRedirect(req.getContextPath() + path);
    }
    public static void error(HttpServletRequest req, String text) { req.setAttribute("error", text); }
}
