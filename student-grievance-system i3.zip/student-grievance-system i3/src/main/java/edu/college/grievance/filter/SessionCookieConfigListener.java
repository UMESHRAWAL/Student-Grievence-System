package edu.college.grievance.filter;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.SessionCookieConfig;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class SessionCookieConfigListener implements ServletContextListener {
    @Override public void contextInitialized(ServletContextEvent event) {
        SessionCookieConfig cookies=event.getServletContext().getSessionCookieConfig();
        cookies.setHttpOnly(true);
        cookies.setAttribute("SameSite","Lax");
        cookies.setSecure(Boolean.parseBoolean(System.getenv().getOrDefault("COOKIE_SECURE","false")));
    }
    @Override public void contextDestroyed(ServletContextEvent event) { }
}
