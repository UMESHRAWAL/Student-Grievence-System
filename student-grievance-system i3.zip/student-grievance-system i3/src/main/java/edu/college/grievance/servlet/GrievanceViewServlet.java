package edu.college.grievance.servlet;

import edu.college.grievance.dao.GrievanceDao;
import edu.college.grievance.dao.UpdateDao;
import edu.college.grievance.model.Grievance;
import edu.college.grievance.model.User;
import edu.college.grievance.util.Validation;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/grievances/view")
public class GrievanceViewServlet extends HttpServlet {
    private final GrievanceDao grievances=new GrievanceDao();private final UpdateDao updates=new UpdateDao();
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        try {long id=Validation.positiveId(req.getParameter("id"));User user=(User)req.getSession().getAttribute("user");Grievance g=grievances.findVisible(id,user);if(g==null){resp.sendError(404);return;}
            req.setAttribute("grievance",g);req.setAttribute("updates",updates.list(id));req.setAttribute("officers",user.isAdmin()?new edu.college.grievance.dao.UserDao().officers():java.util.List.of());req.getRequestDispatcher("/WEB-INF/views/grievance-detail.jsp").forward(req,resp);
        }catch(IllegalArgumentException ex){resp.sendError(400);}catch(Exception ex){getServletContext().log("Grievance load failed",ex);resp.sendError(500);}
    }
}
