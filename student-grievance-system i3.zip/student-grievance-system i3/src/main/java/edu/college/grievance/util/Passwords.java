package edu.college.grievance.util;

import org.mindrot.jbcrypt.BCrypt;

public final class Passwords {
    private Passwords() {}
    public static String hash(String password) { return BCrypt.hashpw(password, BCrypt.gensalt(12)); }
    public static boolean matches(String password, String hash) {
        try { return BCrypt.checkpw(password, hash); } catch (IllegalArgumentException ex) { return false; }
    }
    public static void validate(String password) {
        if (password == null || password.length() < 10 || password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72
                || !password.matches(".*[A-Za-z].*") || !password.matches(".*\\d.*")) {
            throw new IllegalArgumentException("Password must be at least 10 characters, no more than 72 UTF-8 bytes, and contain at least one letter and one number.");
        }
    }
}
