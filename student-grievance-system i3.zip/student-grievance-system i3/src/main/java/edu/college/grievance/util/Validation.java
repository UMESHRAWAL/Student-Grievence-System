package edu.college.grievance.util;

import java.util.Locale;
import java.util.regex.Pattern;

public final class Validation {
    private static final Pattern EMAIL = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", Pattern.CASE_INSENSITIVE);
    private Validation() {}
    public static String clean(String value) { return value == null ? "" : value.trim(); }
    public static String email(String value) {
        String v = clean(value).toLowerCase(Locale.ROOT);
        if (v.length() > 254 || !EMAIL.matcher(v).matches()) throw new IllegalArgumentException("Enter a valid email address.");
        return v;
    }
    public static String bounded(String value, String label, int min, int max) {
        String v = clean(value);
        if (v.length() < min || v.length() > max) throw new IllegalArgumentException(label + " must be between " + min + " and " + max + " characters.");
        return v;
    }
    public static String oneOf(String value, String label, String... allowed) {
        String v = clean(value);
        for (String a : allowed) if (a.equals(v)) return v;
        throw new IllegalArgumentException("Choose a valid " + label + ".");
    }
    public static long positiveId(String value) {
        try { long id = Long.parseLong(value); if (id > 0) return id; }
        catch (Exception ignored) {}
        throw new IllegalArgumentException("Invalid record identifier.");
    }
}
