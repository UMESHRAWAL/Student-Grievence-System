package edu.college.grievance.bootstrap;

import edu.college.grievance.dao.UserDao;
import edu.college.grievance.util.Passwords;
import edu.college.grievance.util.Validation;
import java.io.Console;

/** Creates an administrator from a local terminal; no web route can grant the ADMIN role. */
public final class AdminBootstrap {
    private AdminBootstrap() {}
    public static void main(String[] args) throws Exception {
        Console console=System.console();
        if(console==null)throw new IllegalStateException("Run this command from an interactive terminal so the password is not echoed.");
        UserDao dao=new UserDao();
        long existing=dao.adminCount();
        if(existing>0&&!"ADD".equalsIgnoreCase(console.readLine("There are already %d active admin(s). Type ADD to create another admin: ",existing))) {
            console.writer().println("No admin account was created.");return;
        }
        String name=Validation.bounded(console.readLine("Administrator name: "),"Name",2,100);
        String email=Validation.email(console.readLine("Administrator email: "));
        char[] first=console.readPassword("Password (not shown): ");char[] second=console.readPassword("Confirm password: ");
        try {
            String password=new String(first);
            if(!password.equals(new String(second)))throw new IllegalArgumentException("Passwords do not match.");
            Passwords.validate(password);dao.create(name,email,Passwords.hash(password),"ADMIN");
            console.printf("Admin account created for %s.%n",email);
        } finally {java.util.Arrays.fill(first,'\0');java.util.Arrays.fill(second,'\0');}
    }
}
