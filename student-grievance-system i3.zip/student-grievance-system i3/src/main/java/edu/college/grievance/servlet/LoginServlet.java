package edu.college.grievance.servlet;

import edu.college.grievance.dao.UserDao;
import edu.college.grievance.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final UserDao users=new UserDao();
    private static final String DUMMY_HASH=Passwords.hash("timing-only-password-4821");
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        if(req.getSession().getAttribute("user")!=null){Web.redirect(req,resp,"/dashboard");return;}req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        String email;try{email=Validation.email(req.getParameter("email"));}catch(IllegalArgumentException ex){Web.error(req,"Email or password is incorrect.");req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);return;}
        try {
            UserDao.LoginRecord rec=users.findLogin(email);String password=req.getParameter("password");
            boolean matches=Passwords.matches(password==null?"":password,rec==null?DUMMY_HASH:rec.passwordHash());
            if(rec==null||!matches){Web.error(req,"Email or password is incorrect.");req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);return;}
            req.changeSessionId();req.getSession().setAttribute("user",rec.user());req.getSession().removeAttribute("csrfToken");Csrf.token(req);
            Web.message(req,"success","Welcome back, "+rec.user().getFullName()+".");Web.redirect(req,resp,"/dashboard");
        }catch(Exception ex){getServletContext().log("Login failed",ex);Web.error(req,"Sign-in is temporarily unavailable. Please try again.");req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);}
    }
}
