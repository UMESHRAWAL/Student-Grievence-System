package edu.college.grievance.filter;

import edu.college.grievance.util.Csrf;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class SecurityFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException {
        HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse resp=(HttpServletResponse)response;
        req.setCharacterEncoding("UTF-8");
        String path=req.getRequestURI().substring(req.getContextPath().length());
        resp.setHeader("X-Content-Type-Options","nosniff");resp.setHeader("X-Frame-Options","DENY");resp.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
        resp.setHeader("Content-Security-Policy","default-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'self'; frame-ancestors 'none'; object-src 'none'");
        if(req.isSecure())resp.setHeader("Strict-Transport-Security","max-age=31536000; includeSubDomains");
        HttpSession session=req.getSession(true);session.setMaxInactiveInterval(30*60);
        boolean publicPath=path.equals("/login")||path.equals("/register")||path.startsWith("/assets/")||path.equals("/health");
        if(!publicPath&&session.getAttribute("user")==null){resp.sendRedirect(req.getContextPath()+"/login");return;}
        req.setAttribute("csrfToken",Csrf.token(req));
        req.setAttribute("flashKind",session.getAttribute("flashKind"));
        req.setAttribute("flashMessage",session.getAttribute("flashMessage"));
        session.removeAttribute("flashKind");session.removeAttribute("flashMessage");
        if("POST".equalsIgnoreCase(req.getMethod())&&!Csrf.valid(req)){resp.sendError(HttpServletResponse.SC_FORBIDDEN,"Your form expired. Go back, reload the page, and try again.");return;}
        if("POST".equalsIgnoreCase(req.getMethod()))resp.setHeader("Cache-Control","no-store");
        chain.doFilter(request,response);
    }
}
