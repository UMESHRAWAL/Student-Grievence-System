package edu.college.grievance.servlet;

import edu.college.grievance.dao.UserDao;
import edu.college.grievance.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final UserDao users=new UserDao();
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,resp);}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
        try {
            String name=Validation.bounded(req.getParameter("fullName"),"Name",2,100);String email=Validation.email(req.getParameter("email"));String password=req.getParameter("password");
            Passwords.validate(password);if(!password.equals(req.getParameter("confirmPassword")))throw new IllegalArgumentException("The passwords do not match.");
            users.create(name,email,Passwords.hash(password),"STUDENT");Web.message(req,"success","Your student account is ready. Sign in to continue.");Web.redirect(req,resp,"/login");
        }catch(SQLIntegrityConstraintViolationException ex){Web.error(req,"An account with that email already exists.");req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,resp);}
        catch(IllegalArgumentException ex){Web.error(req,ex.getMessage());req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,resp);}
        catch(Exception ex){getServletContext().log("Registration failed",ex);Web.error(req,"Registration is temporarily unavailable. Please try again.");req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,resp);}
    }
}
