package edu.college.grievance.model;

import java.sql.Timestamp;

public class Grievance {
    private long id;
    private String trackingCode, title, category, priority, description, status, studentName, officerName;
    private int escalationLevel;
    private Timestamp createdAt, updatedAt;

    public long getId() { return id; } public void setId(long v) { id = v; }
    public String getTrackingCode() { return trackingCode; } public void setTrackingCode(String v) { trackingCode = v; }
    public String getTitle() { return title; } public void setTitle(String v) { title = v; }
    public String getCategory() { return category; } public void setCategory(String v) { category = v; }
    public String getPriority() { return priority; } public void setPriority(String v) { priority = v; }
    public String getDescription() { return description; } public void setDescription(String v) { description = v; }
    public String getStatus() { return status; } public void setStatus(String v) { status = v; }
    public String getStudentName() { return studentName; } public void setStudentName(String v) { studentName = v; }
    public String getOfficerName() { return officerName; } public void setOfficerName(String v) { officerName = v; }
    public int getEscalationLevel() { return escalationLevel; } public void setEscalationLevel(int v) { escalationLevel = v; }
    public Timestamp getCreatedAt() { return createdAt; } public void setCreatedAt(Timestamp v) { createdAt = v; }
    public Timestamp getUpdatedAt() { return updatedAt; } public void setUpdatedAt(Timestamp v) { updatedAt = v; }
}
