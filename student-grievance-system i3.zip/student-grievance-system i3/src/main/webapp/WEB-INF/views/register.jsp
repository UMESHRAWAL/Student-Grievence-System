<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Create student account" scope="request"/>
<%@ include file="header.jspf" %>
<section class="narrow card">
  <div class="auth-title"><div class="eyebrow">Student access</div><h1>Create account</h1><p class="muted">Accounts created here receive student access only.</p></div>
  <form method="post" action="${pageContext.request.contextPath}/register">
    <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>">
    <div class="field"><label for="fullName">Full name</label><input class="input" id="fullName" name="fullName" maxlength="100" autocomplete="name" required></div>
    <div class="field"><label for="email">Email</label><input class="input" id="email" name="email" type="email" maxlength="254" autocomplete="email" required></div>
    <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" minlength="10" maxlength="72" autocomplete="new-password" required><small>At least 10 characters, including a letter and a number.</small></div>
    <div class="field"><label for="confirmPassword">Confirm password</label><input class="input" id="confirmPassword" name="confirmPassword" type="password" minlength="10" maxlength="72" autocomplete="new-password" required></div>
    <button class="btn" type="submit">Create student account</button>
  </form>
  <p class="footnote">Already registered? <a href="${pageContext.request.contextPath}/login">Sign in</a></p>
</section>
<%@ include file="footer.jspf" %>
