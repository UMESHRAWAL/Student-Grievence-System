<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Submit a grievance" scope="request"/>
<%@ include file="header.jspf" %>
<div class="page-head"><div><div class="eyebrow">New case</div><h1>Submit a grievance</h1><p class="muted">Describe the issue clearly. You can add updates after submission.</p></div><a class="btn secondary" href="${pageContext.request.contextPath}/dashboard">Back to dashboard</a></div>
<section class="card narrow">
  <div class="danger-note">For immediate danger or an emergency, contact your campus emergency service or local authorities. This project is not monitored as an emergency line.</div>
  <form method="post" action="${pageContext.request.contextPath}/grievances/new">
    <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>">
    <div class="field"><label for="title">Short subject</label><input class="input" id="title" name="title" minlength="5" maxlength="120" required placeholder="A clear summary of the concern"></div>
    <div class="grid"><div class="field"><label for="category">Category</label><select id="category" name="category" required><option value="">Choose a category</option><option value="ACADEMIC">Academic</option><option value="FACILITIES">Facilities</option><option value="HOSTEL">Hostel</option><option value="FINANCE">Finance</option><option value="HARASSMENT">Harassment or conduct</option><option value="OTHER">Other</option></select></div>
    <div class="field"><label for="priority">Priority</label><select id="priority" name="priority"><option value="NORMAL">Normal</option><option value="URGENT">Urgent</option></select><small>Urgent marks the case for staff attention; it does not contact emergency services.</small></div></div>
    <div class="field"><label for="description">Details</label><textarea id="description" name="description" minlength="20" maxlength="4000" required placeholder="Include relevant dates, locations, and what outcome you are seeking."></textarea><small>Do not include passwords, financial account details, or information about other students that is not needed.</small></div>
    <button class="btn" type="submit">Submit grievance</button>
  </form>
</section>
<%@ include file="footer.jspf" %>
