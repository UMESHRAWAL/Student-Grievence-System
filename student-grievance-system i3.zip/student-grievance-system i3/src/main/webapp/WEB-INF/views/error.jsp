<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Page unavailable" scope="request"/>
<%@ include file="header.jspf" %>
<section class="narrow card"><div class="eyebrow">Something went wrong</div><h1>We couldn’t open that page</h1><p class="muted">The page may not exist, or the request could not be completed. Your grievance data has not been shown here.</p><a class="btn" href="${pageContext.request.contextPath}/dashboard">Return to dashboard</a></section>
<%@ include file="footer.jspf" %>
