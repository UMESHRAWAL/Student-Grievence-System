<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Sign in" scope="request"/>
<%@ include file="header.jspf" %>
<section class="narrow card">
  <div class="auth-title"><div class="eyebrow">Student support portal</div><h1>Sign in</h1><p class="muted">Access your cases and updates.</p></div>
  <form method="post" action="${pageContext.request.contextPath}/login">
    <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>">
    <div class="field"><label for="email">Email</label><input class="input" id="email" name="email" type="email" maxlength="254" autocomplete="username" required></div>
    <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" autocomplete="current-password" required></div>
    <button class="btn" type="submit">Sign in</button>
  </form>
  <p class="footnote">New student? <a href="${pageContext.request.contextPath}/register">Create an account</a></p>
</section>
<%@ include file="footer.jspf" %>
