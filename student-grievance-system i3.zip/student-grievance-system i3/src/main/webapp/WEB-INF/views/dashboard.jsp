<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Dashboard" scope="request"/>
<%@ include file="header.jspf" %>
<div class="page-head">
  <div><div class="eyebrow"><c:out value="${sessionScope.user.role}"/> workspace</div><h1><c:choose><c:when test="${sessionScope.user.student}">Your grievances</c:when><c:when test="${sessionScope.user.officer}">Assigned cases</c:when><c:otherwise>Grievance overview</c:otherwise></c:choose></h1>
  <p class="muted"><c:choose><c:when test="${sessionScope.user.student}">Submit a concern and follow every update in one place.</c:when><c:when test="${sessionScope.user.officer}">Review the cases assigned to you and keep students updated.</c:when><c:otherwise>Prioritize, assign, and monitor cases across the system.</c:otherwise></c:choose></p></div>
  <c:if test="${sessionScope.user.student}"><a class="btn" href="${pageContext.request.contextPath}/grievances/new">Submit a grievance</a></c:if>
  <c:if test="${sessionScope.user.admin}"><a class="btn secondary" href="${pageContext.request.contextPath}/admin/officers">Manage officers</a></c:if>
</div>
<section class="card">
  <c:choose><c:when test="${empty grievances}"><div class="empty"><h2>No grievances yet</h2><p>New cases will appear here when they are submitted or assigned.</p><c:if test="${sessionScope.user.student}"><a class="btn" href="${pageContext.request.contextPath}/grievances/new">Submit your first grievance</a></c:if></div></c:when>
  <c:otherwise><div class="table-wrap"><table><thead><tr><th>Tracking code</th><c:if test="${not sessionScope.user.student}"><th>Student</th></c:if><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>
    <c:forEach var="g" items="${grievances}"><tr>
      <td><strong><c:out value="${g.trackingCode}"/></strong><c:if test="${g.escalationLevel gt 0}"><br><span class="badge escalated">Escalated · <c:out value="${g.escalationLevel}"/></span></c:if></td>
      <c:if test="${not sessionScope.user.student}"><td><c:out value="${g.studentName}"/><c:if test="${not empty g.officerName}"><br><small class="muted">Officer: <c:out value="${g.officerName}"/></small></c:if></td></c:if>
      <td><c:out value="${g.title}"/></td><td><c:out value="${g.category}"/></td>
      <td><span class="badge <c:if test='${g.priority eq "URGENT"}'>urgent</c:if>"><c:out value="${g.priority}"/></span></td>
      <td><span class="badge <c:if test='${g.status eq "RESOLVED" or g.status eq "CLOSED"}'>resolved</c:if>"><c:out value="${g.status}"/></span></td>
      <td><fmt:formatDate value="${g.updatedAt}" pattern="dd MMM yyyy, HH:mm"/></td><td><a class="btn small secondary" href="${pageContext.request.contextPath}/grievances/view?id=${g.id}">Open</a></td>
    </tr></c:forEach>
  </tbody></table></div></c:otherwise></c:choose>
</section>
<c:if test="${sessionScope.user.admin}"><p class="footnote">Showing the most recent 250 cases. Keep test data fictional if this demo is hosted publicly.</p></c:if>
<%@ include file="footer.jspf" %>
