CREATE DATABASE IF NOT EXISTS student_grievance
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE student_grievance;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(60) NOT NULL,
  role ENUM('STUDENT','OFFICER','ADMIN') NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_active (role, active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grievances (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  tracking_code CHAR(12) NOT NULL,
  student_id BIGINT NOT NULL,
  assigned_officer_id BIGINT NULL,
  title VARCHAR(120) NOT NULL,
  category ENUM('ACADEMIC','FACILITIES','HOSTEL','FINANCE','HARASSMENT','OTHER') NOT NULL,
  priority ENUM('NORMAL','URGENT') NOT NULL DEFAULT 'NORMAL',
  description TEXT NOT NULL,
  status ENUM('NEW','ASSIGNED','IN_PROGRESS','WAITING_ON_STUDENT','RESOLVED','CLOSED') NOT NULL DEFAULT 'NEW',
  escalation_level TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_grievances_tracking_code (tracking_code),
  KEY idx_grievances_student_created (student_id, created_at),
  KEY idx_grievances_officer_status (assigned_officer_id, status, updated_at),
  KEY idx_grievances_status_priority (status, priority, created_at),
  CONSTRAINT fk_grievances_student FOREIGN KEY (student_id) REFERENCES users(id),
  CONSTRAINT fk_grievances_officer FOREIGN KEY (assigned_officer_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grievance_updates (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  grievance_id BIGINT NOT NULL,
  author_id BIGINT NOT NULL,
  update_type ENUM('MESSAGE','STATUS','ASSIGNMENT','ESCALATION','REOPENED') NOT NULL DEFAULT 'MESSAGE',
  message VARCHAR(2000) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_updates_grievance_created (grievance_id, created_at, id),
  CONSTRAINT fk_updates_grievance FOREIGN KEY (grievance_id) REFERENCES grievances(id) ON DELETE CASCADE,
  CONSTRAINT fk_updates_author FOREIGN KEY (author_id) REFERENCES users(id)
) ENGINE=InnoDB;
