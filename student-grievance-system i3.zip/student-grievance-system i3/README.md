# Campus Resolve

**Student Grievance Registration and Escalation System** — a Java web application for a college project. It uses Java 17, Jakarta Servlets/JSP, JDBC, MySQL 8, and Apache Tomcat 10.1.

## What it does

- Students create accounts, submit grievances, and see only their own cases.
- Admins create officer accounts, assign cases, review the complete queue, and change case status.
- Officers see only cases assigned to them and can post updates or move cases through the review workflow.
- Students and authorized staff can post updates. Each update, assignment, status change, and escalation is recorded in the case timeline.
- Students can reopen a resolved case or confirm it is closed. Open cases can be escalated up to three times; the level is visible in the admin queue.
- Urgent priority and escalation are queue flags; neither sends an email nor contacts emergency services.

## Requirements

- JDK 17
- Apache Maven 3.9 or later
- MySQL 8.0 or later
- Apache Tomcat 10.1 (Jakarta Servlet 6 / JSP 3.1)

Java and JavaScript are different languages. The server-side logic here is Java. JSP generates the pages; HTML and CSS build the browser interface. The project currently needs no client-side JavaScript.

## Local setup

1. Create the database and tables by running `src/main/resources/db/schema.sql` as a MySQL administrator. For example:

   ```sh
   mysql -u root -p < src/main/resources/db/schema.sql
   ```

2. Create a restricted application database account. Use a unique password and keep it out of source control:

   ```sql
   CREATE USER 'grievance_app'@'localhost' IDENTIFIED BY 'replace-with-a-strong-local-password';
   GRANT SELECT, INSERT, UPDATE, DELETE ON student_grievance.* TO 'grievance_app'@'localhost';
   ```

3. Set the database environment variables **in the same environment used to run Maven and Tomcat**. The `.env.example` file shows the expected values, but the app does not load `.env` automatically.

   **Windows PowerShell:**

   ```powershell
   $env:DB_URL = 'jdbc:mysql://localhost:3306/student_grievance?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
   $env:DB_USER = 'grievance_app'
   $env:DB_PASSWORD = 'replace-with-a-strong-local-password'
   ```

   **macOS/Linux:**

   ```sh
   export DB_URL='jdbc:mysql://localhost:3306/student_grievance?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
   export DB_USER='grievance_app'
   export DB_PASSWORD='replace-with-a-strong-local-password'
   ```

4. From this project directory, build the WAR:

   ```sh
   mvn clean package
   ```

5. Create the first administrator from an interactive terminal. The password is read without displaying it; there is no default admin password or public admin-registration page:

   ```sh
   mvn -q exec:java -Dexec.mainClass=edu.college.grievance.bootstrap.AdminBootstrap
   ```

6. Copy `target/grievance.war` into Tomcat's `webapps` directory and start Tomcat. Open `http://localhost:8080/grievance/`.

> If you use an IDE, import this folder as a Maven project, configure JDK 17, and set the three environment variables in the Tomcat run configuration. Deploy the WAR to a Tomcat 10.1 server. Tomcat 9 uses the older `javax.*` APIs and is not compatible with this project.

## Working with teammates

1. Put the project in your shared Git repository and ask each teammate to clone it.
2. Each teammate installs the requirements above, creates the schema, and sets their own local DB credentials. Do not commit `.env`, passwords, database dumps with real records, or production credentials.
3. Build and run the same WAR on each teammate's local Tomcat. The database is separate per person unless the team intentionally configures a shared development database.
4. Share source changes through branches and pull requests. Keep schema changes in a new numbered SQL migration under `src/main/resources/db/migrations/` and document them in the README.

## Case workflow

`NEW → ASSIGNED → IN_PROGRESS ↔ WAITING_ON_STUDENT → RESOLVED → CLOSED`

- An admin assigns an officer; a new case becomes `ASSIGNED` automatically.
- The assigned officer can use `IN_PROGRESS`, `WAITING_ON_STUDENT`, or `RESOLVED` while the case is open.
- A student may reopen a `RESOLVED` case or close it after confirming resolution.
- Admins can correct a status at any stage.
- Escalation is a separate level (0–3) and does not change the case status or reassign it automatically. Admins can review and reassign escalated cases from the dashboard.

## Demo verification checklist

After starting Tomcat, use separate browser sessions (for example, a normal window and a private window) to check the role boundaries and full case flow:

1. Register a student and submit a case. Confirm it appears in that student's dashboard and has a tracking code.
2. Register a second student. Confirm the second account cannot open the first student's case by changing the `id` in the page URL.
3. Sign in as the administrator created by `AdminBootstrap`; create an officer and assign the case.
4. Sign in as that officer. Confirm the assigned case appears, add an update, and move it through `IN_PROGRESS`, `WAITING_ON_STUDENT`, and `RESOLVED`.
5. Sign in as the original student. Confirm the timeline is visible, then reopen the case and escalate it. Confirm the level increases and the admin dashboard flags it.
6. Resolve the reopened case again, then close it as the student. Confirm the closed case no longer accepts messages or escalation.
7. Try posting a form from an old tab after signing out. It should fail safely and require a fresh sign-in.

This is a manual project checklist; it is not an automated test suite.

## Deployment notes

Use localhost during development. For an instructor or teammates to access a demo from their own devices, deploy the WAR to a reachable Tomcat server and connect it to a MySQL database. A public host needs HTTPS, firewall-restricted database access, secret environment variables, backups, and an agreed data-retention policy. Set `COOKIE_SECURE=true` when Tomcat receives the request over HTTPS (including when its proxy or connector is configured to report HTTPS correctly). Free hosting plans can sleep, pause, or have temporary storage, so confirm they support a persistent MySQL database before relying on them for a live demo.

## Project boundaries

This is a college-project foundation, not an approved institutional grievance service. It has no college identity verification, password reset email, outbound email/SMS notifications, attachments, anonymous submissions, or automatic time-based escalation. Users who register as students can provide any email address; role access is still enforced by the app. Do not put real sensitive student complaints into a public demo without college approval and a proper privacy/security review. Use fictional demo accounts and records.

## Security choices in this version

- `ADMIN` cannot be selected during student registration. Admins are provisioned locally; admins create officer accounts.
- Passwords are hashed with BCrypt; database access uses prepared statements.
- Authorization is checked by role and case ownership/assignment before a case is displayed or changed.
- POST forms use session CSRF tokens. Sessions rotate on sign-in and expire after 30 minutes of inactivity.
- Text is HTML-escaped when displayed. Responses include restrictive browser security headers.
- The project intentionally has no default privileged credentials.

These safeguards reduce common application risks, but they do not replace a security review before any real student data is used.
